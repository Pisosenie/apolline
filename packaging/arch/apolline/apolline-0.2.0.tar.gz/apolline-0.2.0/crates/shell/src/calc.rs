pub fn answer(input: &str) -> Option<String> {
    let input = input.trim();
    if let Some(converted) = convert(input) {
        return Some(converted);
    }
    if !input.chars().any(|c| "+-*/^%×÷(".contains(c)) && !input.contains(" of ") {
        return None;
    }
    let value = eval(input)?;
    value.is_finite().then(|| format(value))
}

// Sums of money: "100 usd in eur", "$20 to rub", "50€ in kzt".
pub fn money(input: &str, rates: &crate::rates::Rates) -> Option<String> {
    let lower = input.trim().to_lowercase();
    [" in ", " to "]
        .iter()
        .flat_map(|word| lower.match_indices(word))
        .find_map(|(at, word)| {
            let (amount, from) = amount(&lower[..at])?;
            let to = currency(lower[at + word.len()..].trim())?;
            let value = rates.convert(amount, &from, &to)?;
            rates
                .knows(&from)
                .then(|| format!("{} {to}", money_format(value)))
        })
}

// True when the words look like a sum of money, before any rates are known.
pub fn wants_rates(input: &str) -> bool {
    let lower = input.trim().to_lowercase();
    let known = |code: &str| COMMON.contains(&code);
    [" in ", " to "].iter().any(|word| {
        lower.split_once(word).is_some_and(|(from, to)| {
            amount(from).is_some_and(|(_, code)| known(&code))
                && currency(to.trim()).is_some_and(|code| known(&code))
                && convert(input).is_none()
        })
    })
}

// The currencies worth asking for rates over; any other three letters are likelier a word.
const COMMON: [&str; 44] = [
    "USD", "EUR", "GBP", "JPY", "CNY", "RUB", "KZT", "UAH", "BYN", "UZS", "KGS", "GEL", "AMD",
    "AZN", "TRY", "INR", "CHF", "CAD", "AUD", "NZD", "SEK", "NOK", "DKK", "ISK", "PLN", "CZK",
    "HUF", "RON", "BGN", "RSD", "BRL", "MXN", "ARS", "CLP", "KRW", "SGD", "HKD", "TWD", "THB",
    "IDR", "AED", "SAR", "ILS", "ZAR",
];

const SYMBOLS: [(char, &str); 8] = [
    ('$', "USD"),
    ('€', "EUR"),
    ('£', "GBP"),
    ('₽', "RUB"),
    ('¥', "JPY"),
    ('₸', "KZT"),
    ('₴', "UAH"),
    ('₹', "INR"),
];

fn currency(word: &str) -> Option<String> {
    let word = word.trim();
    let mut chars = word.chars();
    if let (Some(c), None) = (chars.next(), chars.next())
        && let Some((_, code)) = SYMBOLS.iter().find(|(s, _)| *s == c)
    {
        return Some((*code).to_owned());
    }
    (word.len() == 3 && word.chars().all(|c| c.is_ascii_alphabetic()))
        .then(|| word.to_ascii_uppercase())
}

// "100 usd", "$100", "100$", "1,5 €", "2*50 eur".
fn amount(text: &str) -> Option<(f64, String)> {
    let text = text.trim();
    let (number, code) = match text
        .char_indices()
        .find(|(_, c)| SYMBOLS.iter().any(|(s, _)| s == c))
    {
        Some((0, symbol)) => (&text[symbol.len_utf8()..], symbol.to_string()),
        Some((at, symbol)) if at + symbol.len_utf8() == text.len() => {
            (&text[..at], symbol.to_string())
        }
        Some(_) => return None,
        None => {
            let split = text.rfind(|c: char| c.is_whitespace())?;
            (&text[..split], text[split..].to_owned())
        }
    };
    let code = currency(&code)?;
    Some((eval(&thousands(number.trim()))?, code))
}

// "1,000" and "12,500.50" are thousands, while "1,5" stays a decimal comma.
fn thousands(number: &str) -> String {
    let groups: Vec<&str> = number.split(',').collect();
    let whole = groups.len() > 1
        && (1..=3).contains(&groups[0].len())
        && groups[0].chars().all(|c| c.is_ascii_digit())
        && groups[1..].iter().all(|group| {
            let digits = group.split('.').next().unwrap_or_default();
            digits.len() == 3 && digits.chars().all(|c| c.is_ascii_digit())
        });
    if whole {
        number.replace(',', "")
    } else {
        number.to_owned()
    }
}

fn money_format(value: f64) -> String {
    let text = format!("{value:.2}");
    text.strip_suffix(".00").map_or(text.clone(), str::to_owned)
}

const UNITS: [(&str, &str, f64); 30] = [
    ("mm", "length", 0.001),
    ("cm", "length", 0.01),
    ("m", "length", 1.0),
    ("km", "length", 1000.0),
    ("in", "length", 0.0254),
    ("ft", "length", 0.3048),
    ("yd", "length", 0.9144),
    ("mi", "length", 1609.344),
    ("mg", "mass", 0.000_001),
    ("g", "mass", 0.001),
    ("kg", "mass", 1.0),
    ("t", "mass", 1000.0),
    ("oz", "mass", 0.028_349_523_125),
    ("lb", "mass", 0.453_592_37),
    ("b", "data", 1.0),
    ("kb", "data", 1e3),
    ("mb", "data", 1e6),
    ("gb", "data", 1e9),
    ("tb", "data", 1e12),
    ("kib", "data", 1024.0),
    ("mib", "data", 1_048_576.0),
    ("gib", "data", 1_073_741_824.0),
    ("tib", "data", 1_099_511_627_776.0),
    ("s", "time", 1.0),
    ("min", "time", 60.0),
    ("h", "time", 3600.0),
    ("d", "time", 86400.0),
    ("wk", "time", 604_800.0),
    ("ml", "volume", 0.001),
    ("l", "volume", 1.0),
];

fn convert(input: &str) -> Option<String> {
    let lower = input.to_lowercase();
    [" in ", " to "]
        .iter()
        .flat_map(|word| lower.match_indices(word))
        .find_map(|(at, word)| between(&lower[..at], &lower[at + word.len()..]))
}

fn between(from: &str, to: &str) -> Option<String> {
    let from = from.trim();
    let split = from.find(|c: char| c.is_alphabetic() || c == '°')?;
    let (number, unit) = from.split_at(split);
    let value = eval(number.trim())?;
    let (unit, to) = (
        unit.trim().trim_start_matches('°'),
        to.trim().trim_start_matches('°'),
    );
    if let Some(result) = temperature(value, unit, to) {
        return Some(format!("{} °{}", short(result), to.to_uppercase()));
    }
    let find = |name: &str| UNITS.iter().find(|(n, _, _)| *n == name);
    let (_, kind, factor) = find(unit)?;
    let (_, other, into) = find(to)?;
    (kind == other).then(|| format!("{} {}", short(value * factor / into), to_label(to)))
}

fn temperature(value: f64, from: &str, to: &str) -> Option<f64> {
    let kelvin = match from {
        "c" => value + 273.15,
        "f" => (value - 32.0) * 5.0 / 9.0 + 273.15,
        "k" => value,
        _ => return None,
    };
    Some(match to {
        "c" => kelvin - 273.15,
        "f" => (kelvin - 273.15) * 9.0 / 5.0 + 32.0,
        "k" => kelvin,
        _ => return None,
    })
}

fn short(value: f64) -> String {
    let text = format!("{value:.4}");
    text.trim_end_matches('0').trim_end_matches('.').to_owned()
}

fn to_label(unit: &str) -> String {
    match unit {
        "kb" | "mb" | "gb" | "tb" => unit.to_uppercase(),
        "kib" | "mib" | "gib" | "tib" => format!("{}iB", unit[..1].to_uppercase()),
        "b" => "B".into(),
        "l" => "L".into(),
        _ => unit.to_owned(),
    }
}

fn eval(input: &str) -> Option<f64> {
    if let Some((share, whole)) = input.split_once(" of ") {
        let share = share.trim().strip_suffix('%')?;
        return Some(eval(share)? / 100.0 * eval(whole)?);
    }
    let tokens = tokens(input)?;
    let mut parser = Parser { tokens, at: 0 };
    let value = parser.sum()?;
    (parser.at == parser.tokens.len()).then_some(value)
}

#[derive(Clone, Copy, Debug, PartialEq)]
enum Token {
    Number(f64),
    Op(char),
}

fn tokens(input: &str) -> Option<Vec<Token>> {
    let mut out = Vec::new();
    let mut chars = input.chars().peekable();
    while let Some(&c) = chars.peek() {
        match c {
            ' ' | '_' => {
                chars.next();
            }
            '0'..='9' | '.' | ',' => {
                let mut number = String::new();
                while let Some(&d) = chars.peek() {
                    match d {
                        '0'..='9' | '.' => number.push(d),
                        ',' => number.push('.'),
                        '_' => {}
                        _ => break,
                    }
                    chars.next();
                }
                out.push(Token::Number(number.parse().ok()?));
            }
            '+' | '-' | '*' | '/' | '^' | '%' | '(' | ')' => {
                out.push(Token::Op(c));
                chars.next();
            }
            '×' | 'x' => {
                out.push(Token::Op('*'));
                chars.next();
            }
            '÷' => {
                out.push(Token::Op('/'));
                chars.next();
            }
            _ => return None,
        }
    }
    Some(out)
}

struct Parser {
    tokens: Vec<Token>,
    at: usize,
}

impl Parser {
    fn peek(&self) -> Option<Token> {
        self.tokens.get(self.at).copied()
    }

    fn eat(&mut self, op: char) -> bool {
        let found = self.peek() == Some(Token::Op(op));
        if found {
            self.at += 1;
        }
        found
    }

    fn sum(&mut self) -> Option<f64> {
        let mut value = self.product()?;
        loop {
            if self.eat('+') {
                value += self.product()?;
            } else if self.eat('-') {
                value -= self.product()?;
            } else {
                return Some(value);
            }
        }
    }

    fn product(&mut self) -> Option<f64> {
        let mut value = self.unary()?;
        loop {
            if self.eat('*') {
                value *= self.unary()?;
            } else if self.eat('/') {
                value /= self.unary()?;
            } else {
                return Some(value);
            }
        }
    }

    fn unary(&mut self) -> Option<f64> {
        if self.eat('-') {
            return Some(-self.unary()?);
        }
        if self.eat('+') {
            return self.unary();
        }
        self.power()
    }

    fn power(&mut self) -> Option<f64> {
        let base = self.primary()?;
        if self.eat('^') {
            return Some(base.powf(self.unary()?));
        }
        Some(base)
    }

    fn primary(&mut self) -> Option<f64> {
        let mut value = match self.peek()? {
            Token::Number(n) => {
                self.at += 1;
                n
            }
            Token::Op('(') => {
                self.at += 1;
                let inner = self.sum()?;
                if !self.eat(')') {
                    return None;
                }
                inner
            }
            Token::Op(_) => return None,
        };
        while self.eat('%') {
            value /= 100.0;
        }
        Some(value)
    }
}

fn format(value: f64) -> String {
    if value == value.trunc() && value.abs() < 1e15 {
        return format!("{value:.0}");
    }
    let text = format!("{value:.10}");
    text.trim_end_matches('0').trim_end_matches('.').to_owned()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn everyday_sums() {
        assert_eq!(answer("2^10").as_deref(), Some("1024"));
        assert_eq!(answer("15% of 340").as_deref(), Some("51"));
        assert_eq!(answer("(1 + 2) * 3 - 4 / 8").as_deref(), Some("8.5"));
        assert_eq!(answer("-2^2").as_deref(), Some("-4"));
        assert_eq!(answer("2^3^2").as_deref(), Some("512"));
        assert_eq!(answer("1,5 × 4").as_deref(), Some("6"));
        assert_eq!(answer("1/3").as_deref(), Some("0.3333333333"));
        assert_eq!(answer("50%").as_deref(), Some("0.5"));
    }

    #[test]
    fn money_converts_with_the_day_s_rates() {
        let rates = crate::rates::sample();
        assert_eq!(money("100 usd in eur", &rates).as_deref(), Some("92 EUR"));
        assert_eq!(money("$20 to rub", &rates).as_deref(), Some("1630 RUB"));
        assert_eq!(money("50€ in kzt", &rates).as_deref(), Some("27065.22 KZT"));
        assert_eq!(
            money("2*50 EUR in USD", &rates).as_deref(),
            Some("108.70 USD")
        );
        assert_eq!(
            money("100 abc in eur", &rates),
            None,
            "not a currency it knows"
        );
        assert!(wants_rates("100 usd in eur"));
        assert!(wants_rates("$5 to ₽"));
        assert!(!wants_rates("10 km in mi"), "units are no money");
        assert!(!wants_rates("firefox"));
        assert!(
            !wants_rates("10 sec in min"),
            "three letters aren't a currency yet"
        );
        assert_eq!(money("$1,000 in eur", &rates).as_deref(), Some("920 EUR"));
        assert_eq!(
            money("12,500.50 usd in eur", &rates).as_deref(),
            Some("11500.46 EUR")
        );
        assert_eq!(money("1,5 eur in usd", &rates).as_deref(), Some("1.63 USD"));
    }

    #[test]
    fn units_convert_within_their_kind() {
        assert_eq!(answer("10 km in mi").as_deref(), Some("6.2137 mi"));
        assert_eq!(answer("100 F to C").as_deref(), Some("37.7778 °C"));
        assert_eq!(answer("5 GB in MB").as_deref(), Some("5000 MB"));
        assert_eq!(answer("1 GiB in MB").as_deref(), Some("1073.7418 MB"));
        assert_eq!(answer("90 min in h").as_deref(), Some("1.5 h"));
        assert_eq!(answer("2*3 kg to lb").as_deref(), Some("13.2277 lb"));
        assert_eq!(answer("12 in to cm").as_deref(), Some("30.48 cm"));
        assert_eq!(answer("3 ft in in").as_deref(), Some("36 in"));
        assert_eq!(answer("10 km in kg"), None, "length isn't mass");
    }

    #[test]
    fn words_and_bare_numbers_are_left_to_the_launcher() {
        assert_eq!(answer("firefox"), None);
        assert_eq!(answer("42"), None);
        assert_eq!(answer("2 +"), None);
        assert_eq!(answer("1/0"), None);
        assert_eq!(answer("(2"), None);
    }
}
