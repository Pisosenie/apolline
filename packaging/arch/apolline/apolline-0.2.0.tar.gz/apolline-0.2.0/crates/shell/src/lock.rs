use std::path::PathBuf;
use std::sync::mpsc::Sender;
use std::time::Duration;

use crate::lit::button;
use crate::style::text;
use apolline_config::Config;
use apolline_theme::{Palette, Rgba, neutral};
use chrono::{DateTime, Local};
use iced::gradient::Linear;
use iced::keyboard::{self, Key, key::Named};
use iced::widget::operation::focus;
use iced::widget::{
    Space,
    button::{self},
    column, container, image, row, space, stack, text_input,
};
use iced::{
    Alignment, Background, Border, ContentFit, Element, Fill, Font, Gradient, Radians,
    Subscription, Task, Theme, window,
};
use zeroize::Zeroizing;

use crate::auth::{self, Question, Step};
use crate::control::{self, Shared};
use crate::fingerprint::Finger;
use crate::icon::{Icon, icon};
use crate::idle::{self, Stage};
use crate::media::{self, Action, Track};
use crate::power::Battery;
use crate::shell;
use crate::status::short_layout;
use crate::{fonts, niri, power, shot, style, wallpaper};

const FIELD: &str = "lock-password";
const DARK: Rgba = Rgba::hex(0x040508);

pub fn run(preview: bool, mode: Option<String>, screenshot: Option<PathBuf>) -> Result<(), String> {
    if preview || screenshot.is_some() {
        let app = iced::application(
            move || Lock::new(true, mode.clone(), screenshot.clone()),
            Lock::update,
            Lock::view_window,
        )
        .title("Apolline Lock")
        .subscription(Lock::subscription)
        .theme(|_: &Lock| style::theme())
        .default_font(Font::with_name(crate::style::family()))
        .window_size((1440.0, 900.0));
        return fonts::ALL
            .into_iter()
            .fold(app, |app, font| app.font(font))
            .run()
            .map_err(|err| err.to_string());
    }
    session(mode)
}

#[cfg(target_os = "linux")]
fn session(mode: Option<String>) -> Result<(), String> {
    let _guard = match guard(&guard_path()) {
        Guard::Held(file) => Some(file),
        Guard::Busy(file) => {
            // Already locked by us; a sleep waiting on that may go.
            if is_up(file) {
                let _ = control::send("locked");
            }
            return Ok(());
        }
        Guard::Missing(err) => {
            eprintln!("apolline: no lock guard ({err}), locking anyway");
            None
        }
    };
    let app = iced_sessionlock::application(
        move || Lock::new(false, mode.clone(), None),
        Lock::update,
        Lock::view,
    )
    .subscription(Lock::subscription)
    .theme(|_: &Lock| style::theme())
    .default_font(Font::with_name(crate::style::family()));
    fonts::ALL
        .into_iter()
        .fold(app, |app, font| app.font(font))
        .run()
        .map_err(|err| err.to_string())
}

#[cfg(not(target_os = "linux"))]
fn session(_: Option<String>) -> Result<(), String> {
    Err("locking needs a Wayland session on Linux; try --preview".into())
}

fn guard_path() -> PathBuf {
    control::runtime_dir().join("apolline-lock.lock")
}

#[cfg_attr(not(target_os = "linux"), allow(dead_code))]
enum Guard {
    Held(std::fs::File),
    // Another lock of ours is running.
    Busy(std::fs::File),
    // A guard that can't be had doesn't stop the lock; the compositor refuses a second one anyway.
    Missing(String),
}

#[cfg_attr(not(target_os = "linux"), allow(dead_code))]
fn guard(path: &std::path::Path) -> Guard {
    let file = match std::fs::OpenOptions::new()
        .read(true)
        .write(true)
        .create(true)
        .truncate(false)
        .open(path)
    {
        Ok(file) => file,
        Err(err) => return Guard::Missing(err.to_string()),
    };
    match file.try_lock() {
        Ok(()) => {
            // A lock that died leaves its mark behind; this one isn't up yet.
            let _ = file.set_len(0);
            Guard::Held(file)
        }
        Err(std::fs::TryLockError::WouldBlock) => Guard::Busy(file),
        Err(std::fs::TryLockError::Error(err)) => Guard::Missing(err.to_string()),
    }
}

#[cfg_attr(not(target_os = "linux"), allow(dead_code))]
fn is_up(mut file: std::fs::File) -> bool {
    use std::io::Read;
    let mut mark = String::new();
    file.read_to_string(&mut mark).is_ok() && mark == "locked"
}

// Marks the guard and tells the shell, which keeps the machine awake until the lock is up.
async fn locked() {
    let _ = std::fs::write(guard_path(), "locked");
    let _ = tokio::task::spawn_blocking(|| control::send("locked")).await;
}

#[cfg_attr(target_os = "linux", iced_sessionlock::to_session_message)]
#[derive(Clone, Debug)]
pub enum Message {
    Tick,
    Opened,
    Key(keyboard::Event, bool),
    Password(String),
    Submit,
    Auth(u64, Step),
    Wallpaper(Result<image::Handle, String>),
    Battery(Option<Battery>),
    Media(Option<Track>),
    Player(Action),
    Niri(apolline_niri::Event),
    Network(Option<String>),
    Finger(Finger),
    Idle(Stage, bool),
    Shot(window::Screenshot),
    Noop,
}

#[derive(Clone, Debug, PartialEq)]
enum State {
    Typing,
    Checking,
    Asked(Question),
    Wrong(String),
}

struct User {
    login: String,
    name: String,
    face: Option<image::Handle>,
}

struct Lock {
    config: Config,
    mode: Option<usize>,
    user: User,
    password: Zeroizing<String>,
    state: State,
    tries: u64,
    answer: Option<Sender<Zeroizing<String>>>,
    note: Option<String>,
    wallpaper: Option<image::Handle>,
    battery: Option<Battery>,
    track: Option<Track>,
    niri: apolline_niri::State,
    network: Option<String>,
    finger: Option<Finger>,
    waiting: usize,
    weather: Option<(u8, String)>,
    next: Option<String>,
    now: DateTime<Local>,
    ticks: u64,
    preview: bool,
    screenshot: Option<PathBuf>,
    shooting: bool,
    up: bool,
}

impl Lock {
    fn new(
        preview: bool,
        mode: Option<String>,
        screenshot: Option<PathBuf>,
    ) -> (Self, Task<Message>) {
        let (mut config, _) = Config::load(&apolline_config::default_path());
        let shared = control::shared();
        if let Some(wallpaper) = &shared.wallpaper {
            config.desktop.wallpaper = wallpaper.clone();
        }
        let mode = mode
            .or(shared.mode)
            .and_then(|key| config.find(&key))
            .or_else(|| config.start());
        let sample = preview && !niri::connected();
        let lock = Self {
            mode,
            user: if sample {
                User {
                    login: "lena".into(),
                    name: "Lena".into(),
                    face: None,
                }
            } else {
                user()
            },
            password: Zeroizing::new(String::new()),
            state: State::Typing,
            tries: 0,
            answer: None,
            note: None,
            wallpaper: None,
            battery: sample.then_some(Battery {
                percent: 82,
                charging: false,
                left: Some(190),
            }),
            track: sample.then(|| Track::sample("Night Drive", "Low Tide")),
            niri: apolline_niri::State::default(),
            network: sample.then(|| "Polina".to_owned()),
            finger: (sample && config.lock.fingerprint).then_some(Finger::Ready(false)),
            waiting: if sample { 2 } else { shared.waiting },
            weather: if sample {
                Some((2, "17° Partly cloudy · Lisbon".to_owned()))
            } else {
                shared.weather
            },
            next: if sample {
                Some("Design review · in 10 min".to_owned())
            } else {
                shared.next
            },
            now: Local::now(),
            ticks: 0,
            preview,
            screenshot,
            shooting: false,
            up: false,
            config,
        };
        let name = match lock.config.wallpaper(mode) {
            // Drawn by another program the lock can't show; its own picture instead.
            apolline_config::NO_WALLPAPER => apolline_config::Config::default().desktop.wallpaper,
            name => name.to_owned(),
        };
        let load = if lock.config.lock.blur {
            Task::perform(wallpaper::load_blurred(name), Message::Wallpaper)
        } else {
            Task::perform(wallpaper::load(name), Message::Wallpaper)
        };
        let network = if sample { Task::none() } else { read_network() };
        (lock, Task::batch([load, network, focus(FIELD)]))
    }

    fn palette(&self) -> Palette {
        self.config.palette(self.mode)
    }

    // Typing clears a refusal but keeps a question PAM is waiting on.
    fn typing(&mut self) {
        if matches!(self.state, State::Wrong(_)) {
            self.state = State::Typing;
        }
    }

    fn update(&mut self, message: Message) -> Task<Message> {
        match message {
            Message::Tick => {
                self.now = Local::now();
                self.ticks += 1;
                if !self.preview {
                    let Shared {
                        waiting,
                        weather,
                        next,
                        ..
                    } = control::shared();
                    self.waiting = waiting;
                    self.weather = weather;
                    self.next = next;
                }
                if self.screenshot.is_some() && !self.shooting && self.wallpaper.is_some() {
                    self.shooting = true;
                    return window::latest()
                        .and_then(window::screenshot)
                        .map(Message::Shot);
                }
                if self.ticks.is_multiple_of(15) && !self.preview {
                    return read_network();
                }
            }
            Message::Opened if !self.preview && !self.up => {
                self.up = true;
                return Task::batch([focus(FIELD), Task::future(locked()).discard()]);
            }
            Message::Opened => return focus(FIELD),
            Message::Key(keyboard::Event::KeyPressed { key, text, .. }, captured) => {
                if self.state == State::Checking {
                    return Task::none();
                }
                match key.as_ref() {
                    Key::Named(Named::Escape) => {
                        self.password.clear();
                        self.state = State::Typing;
                        self.answer = None;
                        self.note = None;
                    }
                    _ if captured => {}
                    Key::Named(Named::Enter) => return self.update(Message::Submit),
                    Key::Named(Named::Backspace) => {
                        self.password.pop();
                    }
                    _ => {
                        if let Some(typed) = text.filter(|t| t.chars().all(|c| !c.is_control())) {
                            self.password.push_str(&typed);
                            self.typing();
                        }
                    }
                }
            }
            Message::Password(password) => {
                self.password = Zeroizing::new(password);
                self.typing();
            }
            Message::Submit => {
                if self.password.is_empty() || self.state == State::Checking {
                    return Task::none();
                }
                let typed = std::mem::replace(&mut self.password, Zeroizing::new(String::new()));
                if let Some(answer) = self.answer.take() {
                    self.state = State::Checking;
                    let _ = answer.send(typed);
                    return Task::none();
                }
                if self.preview {
                    self.state = State::Wrong("This is a preview, nothing to unlock".into());
                    return Task::none();
                }
                self.state = State::Checking;
                self.tries += 1;
                self.note = None;
                let tries = self.tries;
                return Task::run(auth::check(self.user.login.clone(), typed), move |step| {
                    Message::Auth(tries, step)
                });
            }
            Message::Auth(tries, _) if tries != self.tries => {}
            Message::Auth(_, Step::Ask(question, answer)) => {
                self.state = State::Asked(question);
                self.answer = Some(answer);
                return focus(FIELD);
            }
            Message::Auth(_, Step::Note(note)) => self.note = Some(note),
            Message::Auth(_, Step::Done(Ok(()))) => return unlock(),
            Message::Auth(_, Step::Done(Err(err))) => {
                self.answer = None;
                self.note = None;
                // Escape already took the user back to the password.
                if matches!(self.state, State::Checking | State::Asked(_)) {
                    self.state = State::Wrong(err);
                }
                return focus(FIELD);
            }
            Message::Wallpaper(Ok(handle)) => self.wallpaper = Some(handle),
            Message::Wallpaper(Err(err)) => eprintln!("apolline: wallpaper: {err}"),
            Message::Battery(battery) => self.battery = battery,
            Message::Media(track) => self.track = track,
            Message::Player(action) => {
                if let Some(track) = &mut self.track {
                    if track.player.is_empty() {
                        track.playing = !track.playing;
                    } else {
                        return Task::future(media::control(track.player.clone(), action))
                            .discard();
                    }
                }
            }
            Message::Niri(event) => self.niri.apply(event),
            Message::Network(network) => self.network = network,
            Message::Finger(Finger::Matched) if !self.preview => return unlock(),
            Message::Finger(finger) => self.finger = Some(finger),
            Message::Idle(Stage::ScreenOff, true) if !self.preview => {
                return Task::future(async {
                    let _ = tokio::process::Command::new("niri")
                        .args(["msg", "action", "power-off-monitors"])
                        .status()
                        .await;
                })
                .discard();
            }
            Message::Shot(capture) => {
                if let Some(path) = self.screenshot.take()
                    && let Err(err) = shot::save(&path, &capture)
                {
                    eprintln!("apolline: could not save {}: {err}", path.display());
                }
                return iced::exit();
            }
            _ => {}
        }
        Task::none()
    }

    fn subscription(&self) -> Subscription<Message> {
        Subscription::batch([
            iced::time::every(Duration::from_secs(1)).map(|_| Message::Tick),
            window::open_events().map(|_| Message::Opened),
            iced::event::listen_with(|event, status, _| match event {
                iced::Event::Keyboard(key @ keyboard::Event::KeyPressed { .. }) => {
                    Some(Message::Key(key, status == iced::event::Status::Captured))
                }
                _ => None,
            }),
            power::subscription().map(|message| match message {
                shell::Message::Battery(battery) => Message::Battery(battery),
                _ => Message::Noop,
            }),
            media::subscription().map(|message| match message {
                shell::Message::Media(track) => Message::Media(track),
                _ => Message::Noop,
            }),
            niri::events().map(|message| match message {
                shell::Message::Niri(event) => Message::Niri(event),
                _ => Message::Noop,
            }),
            idle::subscription(if self.preview {
                Vec::new()
            } else {
                vec![(Stage::ScreenOff, 30)]
            })
            .map(|(stage, idle)| Message::Idle(stage, idle)),
            crate::fingerprint::subscription(!self.preview && self.config.lock.fingerprint)
                .map(Message::Finger),
        ])
    }

    fn view_window(&self) -> Element<'_, Message> {
        self.view(window::Id::unique())
    }

    fn view(&self, _: window::Id) -> Element<'_, Message> {
        let palette = self.palette();
        let picture: Element<'_, Message> = match &self.wallpaper {
            Some(handle) => image(handle.clone())
                .width(Fill)
                .height(Fill)
                .content_fit(ContentFit::Cover)
                .into(),
            None => Space::new().width(Fill).height(Fill).into(),
        };
        let shade = container(Space::new().width(Fill).height(Fill)).style(|_| {
            let dark = |alpha: f32| style::color(DARK.alpha(alpha));
            container::Style {
                background: Some(Background::Gradient(Gradient::Linear(
                    Linear::new(Radians(std::f32::consts::PI))
                        .add_stop(0.0, dark(0.35))
                        .add_stop(0.22, dark(0.0))
                        .add_stop(0.42, dark(0.0))
                        .add_stop(1.0, dark(0.7)),
                ))),
                ..container::Style::default()
            }
        });

        let top = row![self.mode_pill(palette), space::horizontal(), self.status()]
            .align_y(Alignment::Center)
            .padding([32, 40]);

        let clock = column![
            text(
                self.now
                    .format(&crate::i18n::names("%A, %-d %B", &self.now))
                    .to_string()
                    .to_uppercase()
            )
            .size(14)
            .font(style::medium())
            .color(style::color(neutral::text().alpha(0.86))),
            text(
                self.now
                    .format(&crate::i18n::names(
                        self.config.clock.time(false),
                        &self.now
                    ))
                    .to_string(),
            )
            .size(232)
            .font(style::light())
            .line_height(0.92),
        ]
        .spacing(4);

        let centered = self.config.lock.centered;
        let clock = if centered {
            clock.align_x(Alignment::Center)
        } else {
            clock
        };
        let left = column![clock, space().height(36), self.field(palette), self.hint()]
            .spacing(12)
            .max_width(560);
        let left = if centered {
            left.align_x(Alignment::Center)
        } else {
            left
        };

        let mut right = column![].spacing(14).align_x(Alignment::End);
        let line = |glyph: Option<Icon>, words: &str| {
            let tint = neutral::text().alpha(0.86);
            let mut line = row![].spacing(8).align_y(Alignment::Center);
            line = match glyph {
                Some(glyph) => line.push(icon(glyph, 15.0, tint)),
                None => line.push(
                    container(Space::new().width(6).height(6)).style(style::dot(palette.accent)),
                ),
            };
            line.push(text(words.to_owned()).size(13).color(style::color(tint)))
        };
        if let Some((code, words)) = self
            .weather
            .as_ref()
            .filter(|_| self.config.lock.show_weather)
        {
            right = right.push(line(Some(crate::weather::describe(*code).0), words));
        }
        if let Some(next) = self.next.as_ref().filter(|_| self.config.lock.show_next) {
            right = right.push(line(None, next));
        }
        if self.config.lock.show_media
            && let Some(track) = &self.track
        {
            right = right.push(player(track, palette));
        }
        if self.waiting > 0 && self.config.lock.show_count {
            let line = crate::i18n::count(
                self.waiting,
                "1 notification · hidden until you unlock",
                "{n} notifications · hidden until you unlock",
            );
            right = right.push(
                row![
                    icon(Icon::Lock, 12.0, neutral::text().alpha(0.8)),
                    text(line)
                        .size(12)
                        .color(style::color(neutral::text().alpha(0.8))),
                ]
                .spacing(8)
                .align_y(Alignment::Center),
            );
        }

        // In the middle: the clock and the password at the centre, the rest along the bottom.
        let body: Element<'_, Message> = if centered {
            column![
                top,
                space::vertical(),
                container(left).center_x(Fill),
                space::vertical(),
                row![space::horizontal(), right].padding(iced::Padding::new(40.0).top(0.0)),
            ]
            .width(Fill)
            .height(Fill)
            .into()
        } else {
            let bottom = row![left, space::horizontal(), right]
                .align_y(Alignment::End)
                .padding(iced::Padding::new(88.0).top(0.0));
            column![top, space::vertical(), bottom]
                .width(Fill)
                .height(Fill)
                .into()
        };

        container(stack![picture, shade, body])
            .style(|_| container::background(style::color(neutral::ink())))
            .into()
    }

    fn mode_pill(&self, palette: Palette) -> Option<Element<'_, Message>> {
        let mode = self.mode.and_then(|i| self.config.modes.get(i))?;
        let pill = container(
            row![
                container(Space::new().width(6).height(6)).style(style::dot(palette.accent)),
                text(mode.name.as_str()).size(12).font(style::medium()),
            ]
            .spacing(8)
            .align_y(Alignment::Center),
        )
        .padding([7, 12])
        .style(glass(0.45, 0.1, style::PILL));
        Some(pill.into())
    }

    fn status(&self) -> Element<'_, Message> {
        let tint = style::color(neutral::text().alpha(0.86));
        let mut items = row![].spacing(18).align_y(Alignment::Center);
        if let Some(layout) = self.layout() {
            items = items.push(text(layout).size(12).font(style::mono()).color(tint));
        }
        if let Some(network) = &self.network {
            items = items.push(
                row![
                    icon(Icon::Wifi, 13.0, neutral::text().alpha(0.86)),
                    text(network.as_str()).size(12).color(tint)
                ]
                .spacing(6)
                .align_y(Alignment::Center),
            );
        }
        if let Some(battery) = self.battery {
            items = items.push(
                row![
                    icon(
                        Icon::battery(battery.percent, battery.charging),
                        15.0,
                        neutral::text().alpha(0.86)
                    ),
                    text(format!("{}%", battery.percent))
                        .size(12)
                        .font(style::mono())
                        .color(tint),
                ]
                .spacing(6)
                .align_y(Alignment::Center),
            );
        }
        items.into()
    }

    fn layout(&self) -> Option<String> {
        match self.niri.layout() {
            Some(name) => Some(short_layout(name)),
            None if self.preview => Some("EN".to_owned()),
            None => None,
        }
    }

    fn field(&self, palette: Palette) -> Element<'_, Message> {
        let avatar: Element<'_, Message> = match &self.user.face {
            Some(face) => image(face.clone())
                .width(36)
                .height(36)
                .content_fit(ContentFit::Cover)
                .border_radius(18.0)
                .into(),
            None => container(
                text(initial(&self.user.name))
                    .size(14)
                    .font(style::semibold())
                    .color(style::color(palette.on_accent)),
            )
            .center(36)
            .style(style::pill(palette.accent))
            .into(),
        };
        let checking = self.state == State::Checking;
        let (asked, shown) = match &self.state {
            State::Checking => (crate::i18n::t("Checking…"), false),
            State::Asked(question) => (question.text.trim().trim_end_matches(':'), question.shown),
            _ => (crate::i18n::t("Password"), false),
        };
        let mut input = text_input(asked, &self.password)
            .id(FIELD)
            .secure(!shown)
            .size(15)
            .padding(0)
            .style(style::bare_field(palette));
        if !checking {
            input = input.on_input(Message::Password).on_submit(Message::Submit);
        }
        let mut line = row![
            avatar,
            text(self.user.name.clone()).size(14).font(style::medium()),
            input,
        ]
        .spacing(12)
        .align_y(Alignment::Center);
        if let Some(layout) = self.layout() {
            line = line.push(
                text(layout)
                    .size(11)
                    .font(style::mono())
                    .color(style::color(style::faint())),
            );
        }
        line = line.push(
            button(container(icon(Icon::Arrow, 16.0, neutral::text())).center(36))
                .padding(0)
                .style(|_: &Theme, status| button::Style {
                    background: Some(Background::Color(style::color(Rgba::hex(0xffffff).alpha(
                        match status {
                            button::Status::Hovered | button::Status::Pressed => 0.22,
                            _ => 0.14,
                        },
                    )))),
                    border: Border {
                        radius: style::PILL.into(),
                        ..Border::default()
                    },
                    ..button::Style::default()
                })
                .on_press_maybe((!checking).then_some(Message::Submit)),
        );
        let edge = match self.state {
            State::Wrong(_) => style::DANGER.alpha(0.8),
            _ => Rgba::hex(0xffffff).alpha(0.12),
        };
        container(line)
            .width(420)
            .height(56)
            .padding([0, 10])
            .align_y(Alignment::Center)
            .style(move |_| container::Style {
                background: Some(Background::Color(style::color(
                    Rgba::hex(0x0c0d10).alpha(0.5),
                ))),
                border: Border {
                    color: style::color(edge),
                    width: 1.0,
                    radius: 28.0.into(),
                },
                ..container::Style::default()
            })
            .into()
    }

    fn hint(&self) -> Element<'_, Message> {
        let finger = match &self.finger {
            Some(Finger::Ready(false)) => "Or touch the fingerprint reader",
            Some(Finger::Ready(true)) => "Or swipe a finger on the reader",
            Some(Finger::Again) => "Not recognized, try again",
            Some(Finger::Matched) => "Unlocking…",
            Some(Finger::Gone(why)) => why,
            None => "",
        };
        match &self.state {
            State::Wrong(reason) => text(reason.as_str())
                .size(13)
                .color(style::color(style::DANGER))
                .into(),
            _ if let Some(note) = &self.note => text(note.as_str())
                .size(13)
                .color(style::color(style::faint()))
                .into(),
            _ if !finger.is_empty() => row![
                icon(Icon::Fingerprint, 14.0, style::faint()),
                text(finger).size(13).color(style::color(style::faint())),
            ]
            .spacing(8)
            .align_y(Alignment::Center)
            .into(),
            _ => Space::new().height(16).into(),
        }
    }
}

fn player(track: &Track, palette: Palette) -> Element<'_, Message> {
    let mut words = column![
        text(media::shorten(&track.title, 28))
            .size(15)
            .font(style::medium())
    ]
    .spacing(3)
    .width(Fill);
    if let Some(artist) = &track.artist {
        words = words.push(
            text(media::shorten(artist, 32))
                .size(13)
                .color(style::color(neutral::muted())),
        );
    }
    container(
        row![
            container(icon(Icon::Music, 24.0, palette.accent))
                .center(64)
                .style(move |_| container::Style {
                    background: Some(Background::Color(style::color(palette.accent_soft))),
                    border: Border {
                        radius: 10.0.into(),
                        ..Border::default()
                    },
                    ..container::Style::default()
                }),
            words,
            button(
                container(icon(
                    if track.playing {
                        Icon::Pause
                    } else {
                        Icon::Play
                    },
                    14.0,
                    neutral::text()
                ))
                .center(36)
            )
            .padding(0)
            .style(|_: &Theme, _| button::Style {
                background: Some(Background::Color(style::color(
                    Rgba::hex(0xffffff).alpha(0.12)
                ))),
                border: Border {
                    radius: style::PILL.into(),
                    ..Border::default()
                },
                ..button::Style::default()
            })
            .on_press(Message::Player(Action::Toggle)),
        ]
        .spacing(14)
        .align_y(Alignment::Center),
    )
    .width(340)
    .padding(14)
    .style(glass(0.5, 0.1, 18.0))
    .into()
}

fn glass(alpha: f32, edge: f32, radius: f32) -> impl Fn(&Theme) -> container::Style {
    move |_| container::Style {
        text_color: Some(style::color(neutral::text())),
        background: Some(Background::Color(style::color(
            Rgba::hex(0x0c0d10).alpha(alpha),
        ))),
        border: Border {
            color: style::color(Rgba::hex(0xffffff).alpha(edge)),
            width: 1.0,
            radius: radius.into(),
        },
        ..container::Style::default()
    }
}

fn initial(name: &str) -> String {
    name.chars()
        .next()
        .map(|c| c.to_uppercase().to_string())
        .unwrap_or_default()
}

fn read_network() -> Task<Message> {
    Task::perform(crate::wifi::connected(), Message::Network)
}

#[cfg(target_os = "linux")]
fn unlock() -> Task<Message> {
    Task::done(Message::UnLock)
}

#[cfg(not(target_os = "linux"))]
fn unlock() -> Task<Message> {
    iced::exit()
}

fn user() -> User {
    let uid = std::fs::metadata("/proc/self")
        .ok()
        .map(|meta| std::os::unix::fs::MetadataExt::uid(&meta));
    let passwd = std::fs::read_to_string("/etc/passwd").unwrap_or_default();
    let entry = uid.and_then(|uid| account(&passwd, uid));
    let login = entry
        .as_ref()
        .map(|(login, _)| login.clone())
        .or_else(|| std::env::var("USER").ok())
        .unwrap_or_default();
    let name = entry
        .and_then(|(_, name)| name)
        .unwrap_or_else(|| login.clone());
    let face = [
        std::env::var_os("HOME").map(|home| PathBuf::from(home).join(".face")),
        Some(PathBuf::from("/var/lib/AccountsService/icons").join(&login)),
    ]
    .into_iter()
    .flatten()
    .find(|path| path.is_file())
    .map(image::Handle::from_path);
    User { login, name, face }
}

fn account(passwd: &str, uid: u32) -> Option<(String, Option<String>)> {
    passwd.lines().find_map(|line| {
        let fields: Vec<&str> = line.split(':').collect();
        if fields.len() < 5 || fields[2].parse::<u32>().ok()? != uid {
            return None;
        }
        let name = fields[4]
            .split(',')
            .next()
            .map(str::trim)
            .filter(|n| !n.is_empty())
            .map(str::to_owned);
        Some((fields[0].to_owned(), name))
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_account_comes_from_passwd() {
        let passwd = "root:x:0:0::/root:/bin/bash\ndanil:x:1000:1000:Danil Zorin,,,:/home/danil:/bin/zsh\nbot:x:1001:1001::/home/bot:/bin/sh\n";
        assert_eq!(
            account(passwd, 1000),
            Some(("danil".into(), Some("Danil Zorin".into())))
        );
        assert_eq!(account(passwd, 1001), Some(("bot".into(), None)));
        assert_eq!(account(passwd, 42), None);
        assert_eq!(initial("danil"), "D");
    }

    #[test]
    fn one_lock_at_a_time_and_a_dead_ones_mark_is_cleared() {
        let dir = std::env::temp_dir().join(format!("apolline-guard-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("apolline-lock.lock");
        std::fs::write(&path, "locked").unwrap();
        let Guard::Held(held) = guard(&path) else {
            panic!("the first lock holds the guard");
        };
        assert_eq!(std::fs::read_to_string(&path).unwrap(), "");
        let Guard::Busy(busy) = guard(&path) else {
            panic!("a second lock finds it busy");
        };
        assert!(!is_up(busy));
        std::fs::write(&path, "locked").unwrap();
        let Guard::Busy(busy) = guard(&path) else {
            panic!("still busy");
        };
        assert!(is_up(busy));
        drop(held);
        assert!(matches!(guard(&dir.join("no/such/dir")), Guard::Missing(_)));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn a_wrong_password_clears_the_field_and_says_so() {
        let (mut lock, _) = Lock::new(true, Some("evening".into()), None);
        let _ = lock.update(Message::Password("hunter2".into()));
        lock.state = State::Checking;
        let _ = lock.update(Message::Auth(0, Step::Done(Err("Wrong password".into()))));
        assert_eq!(lock.state, State::Wrong("Wrong password".into()));
        let _ = lock.update(Message::Password("h".into()));
        assert_eq!(lock.state, State::Typing);
        assert_eq!(lock.mode, lock.config.find("evening"));
    }

    #[test]
    fn a_question_from_pam_is_answered_from_the_field_and_escape_drops_it() {
        let (mut lock, _) = Lock::new(true, None, None);
        lock.state = State::Checking;
        let code = Question {
            text: "Verification code: ".into(),
            shown: true,
        };
        let (answer, answers) = std::sync::mpsc::channel();
        let _ = lock.update(Message::Auth(0, Step::Ask(code.clone(), answer)));
        assert_eq!(lock.state, State::Asked(code.clone()));
        let _ = lock.update(Message::Password("4242".into()));
        assert_eq!(lock.state, State::Asked(code.clone()));
        let _ = lock.update(Message::Submit);
        assert_eq!(answers.recv().unwrap().as_str(), "4242");
        assert_eq!(lock.state, State::Checking);

        let (answer, answers) = std::sync::mpsc::channel();
        let _ = lock.update(Message::Auth(0, Step::Ask(code, answer)));
        let escape = keyboard::Event::KeyPressed {
            key: Key::Named(Named::Escape),
            modified_key: Key::Named(Named::Escape),
            physical_key: keyboard::key::Physical::Unidentified(
                keyboard::key::NativeCode::Unidentified,
            ),
            location: keyboard::Location::Standard,
            modifiers: keyboard::Modifiers::empty(),
            text: None,
            repeat: false,
        };
        let _ = lock.update(Message::Key(escape, false));
        assert!(answers.recv().is_err());
        let _ = lock.update(Message::Auth(
            0,
            Step::Done(Err("Conversation error".into())),
        ));
        assert_eq!(lock.state, State::Typing);
        let _ = lock.update(Message::Auth(7, Step::Done(Ok(()))));
        assert_eq!(lock.state, State::Typing);
    }
}
