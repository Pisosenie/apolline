use std::process::ExitCode;

use apolline_config::{Config, Editor, Plugin};

use super::install::Refused;
use super::{Installed, install, installed};

pub const USAGE: &str = "apolline plugin list | install [--replace] PATH|LINK | remove NAME | enable NAME | disable NAME";

pub fn main(args: &[String]) -> ExitCode {
    let replace = args.iter().any(|a| a == "--replace");
    let mut words = args
        .iter()
        .map(String::as_str)
        .filter(|a| *a != "--replace");
    let done = match (words.next(), words.next()) {
        (None | Some("list"), _) => {
            list();
            Ok(())
        }
        (Some("install"), Some(from)) => install(from, replace),
        (Some("remove"), Some(name)) => install::remove(name).and_then(|()| {
            println!("{name} is removed");
            retire(name)
        }),
        (Some("enable"), Some(name)) => enable(name),
        (Some("disable"), Some(name)) => switch(name, false).map(|()| println!("{name} is off")),
        _ => {
            eprintln!("usage: {USAGE}");
            return ExitCode::from(2);
        }
    };
    match done {
        Ok(()) => ExitCode::SUCCESS,
        Err(err) => {
            eprintln!("apolline: {err}");
            ExitCode::FAILURE
        }
    }
}

fn list() {
    let path = apolline_config::default_path();
    let (config, _) = Config::load(&path);
    let all = installed();
    if all.is_empty() {
        println!("No plugins yet; `apolline plugin install PATH|LINK` adds one");
    }
    for found in &all {
        let plugin = &found.plugin;
        let mark = if config.plugins.is_enabled(&plugin.name) {
            '*'
        } else {
            ' '
        };
        let version = if plugin.version.is_empty() {
            String::new()
        } else {
            format!(" {}", plugin.version)
        };
        println!("{mark} {}{version} — {}", plugin.name, plugin.about);
        if !plugin.author.is_empty() {
            println!("    by {}", plugin.author);
        }
        if !found.yours() {
            println!("    from a package, in {}", found.dir.display());
        }
        if !found.problems.is_empty() {
            println!(
                "    {} problem(s); `apolline check` says which",
                found.problems.len()
            );
        }
    }
}

fn install(from: &str, replace: bool) -> Result<(), String> {
    let found = install::install(from, replace).map_err(|refused| match refused {
        Refused::Taken(name) => format!(
            "“{name}” is installed already; `apolline plugin install --replace {from}` puts this one in its place"
        ),
        Refused::Wrong(why) => why,
    })?;
    if replace {
        retire(&found.plugin.name)?;
    }
    installed_one(&found);
    Ok(())
}

// Off, and its secrets forgotten, so nothing put in its place under the name runs at once or
// inherits them.
fn retire(name: &str) -> Result<(), String> {
    switch(name, false)?;
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .map_err(|err| err.to_string())?;
    runtime.block_on(crate::secrets::plugin_forget_all(name))
}

// What it will run, said before it's ever enabled.
fn installed_one(found: &Installed) {
    let plugin = &found.plugin;
    println!("{} is installed in {}", plugin.name, found.dir.display());
    println!("Once enabled, it runs these as you, in that folder:");
    for (what, command) in plugin.commands() {
        println!("  {what}: {command}");
    }
    println!("`apolline plugin enable {}` turns it on", plugin.name);
}

fn enable(name: &str) -> Result<(), String> {
    let found = installed()
        .into_iter()
        .find(|p| p.plugin.name == name)
        .ok_or_else(|| format!("no plugin called “{name}” is installed"))?;
    switch(name, true)?;
    println!("{name} is on");
    if !found.problems.is_empty() {
        println!("Its plugin.toml has problems; `apolline check` says which");
    }
    for line in placing(&found.plugin) {
        println!("  {line}");
    }
    Ok(())
}

// Where its parts go, since nothing is placed for you.
pub fn placing(plugin: &Plugin) -> Vec<String> {
    let named = |part: &str| format!("{}.{part}", plugin.name);
    let fill = crate::i18n::fill;
    let mut lines = Vec::new();
    for piece in plugin.bar.iter().filter_map(|m| m.name.as_deref()) {
        lines.push(fill(
            "On the bar: add “{piece}” to [bar] left, center or right",
            &[("piece", &named(piece))],
        ));
    }
    for widget in plugin.widgets.iter().filter_map(|m| m.name.as_deref()) {
        lines.push(fill(
            "On the desktop: add “{widget}” to [desktop] widgets",
            &[("widget", &named(widget))],
        ));
    }
    for tile in &plugin.tiles {
        lines.push(fill(
            "In quick settings: add “{tile}” to [panel] tiles",
            &[("tile", &named(&tile.name))],
        ));
    }
    if !plugin.launchers.is_empty() {
        lines.push(crate::i18n::t("In the launcher: it answers searches now").to_owned());
    }
    lines
}

// Turns it on or off in [plugins] enabled.
pub fn switch(name: &str, on: bool) -> Result<(), String> {
    let path = apolline_config::default_path();
    let (config, _) = Config::load(&path);
    let mut enabled: Vec<String> = config
        .plugins
        .enabled
        .iter()
        .filter(|n| *n != name)
        .cloned()
        .collect();
    if on {
        enabled.push(name.to_owned());
    }
    if enabled == config.plugins.enabled {
        return Ok(());
    }
    let mut editor = Editor::load(&path)?;
    set_enabled(&mut editor, &enabled);
    editor
        .save(&path)
        .map_err(|err| format!("{}: {err}", path.display()))
}

pub fn set_enabled(editor: &mut Editor, enabled: &[String]) {
    if enabled.is_empty() {
        editor.unset("plugins", "enabled");
    } else {
        editor.set_list("plugins", "enabled", enabled);
    }
}

// `apolline check`: the enabled plugins' own files, after the config.
pub fn problems(config: &Config, all: &[Installed]) -> Vec<String> {
    all.iter()
        .filter(|p| config.plugins.is_enabled(&p.plugin.name))
        .flat_map(|p| {
            p.problems
                .iter()
                .map(|problem| format!("{}:{}: {problem}", p.manifest().display(), problem.line))
        })
        .collect()
}
