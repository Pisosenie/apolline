# Apolline roadmap

The goal: the desktop people pick niri for, without the evening of config reading.
Install it, run `apolline setup`, and the first login already looks finished.
Everything you can see you can change by clicking, and the file shows what changed.

## Who it is for

- **The developer on a laptop.** Terminal, editor and browser side by side, lots of copy and paste,
  a few hours of focus a day. Wants the keyboard for everything and a clipboard that remembers.
- **The player.** Wants games to run as fast as the machine allows, nothing popping up mid-match,
  and the screen to stay on while the gamepad is in hand.
- **The one coming from GNOME or macOS.** Expects a settings window, a launcher, quick settings,
  a lock screen and a clear way out of every screen. Never wants to open a KDL file.

## Why people leave HyDE for it

HyDE shows how much people want a riced Hyprland that looks good out of the box. Apolline keeps that
promise and drops the cost: everything HyDE lets you change, in a window, layered, and nothing breaks
on update.

- **One command, nothing to babysit.** A package and `apolline setup`; updates never overwrite your files.
- **A window instead of scripts.** Every option has a control and a live preview; the file still works
  and shows what changed, and Ctrl+Z takes any change back.
- **Colors from your wallpaper** without pywal and a theme folder per look.
- **Eye candy you can dial:** opacity, dimming, corners, shadows, gradient borders, blur, how windows
  move and appear, per app if you want, each one a control and a line in the config.
- **Fast with the keyboard:** Alt+Tab, launcher, clipboard, every shortcut listed and searchable.
- **Games first-class:** a mode that turns on by itself when a game starts, VRR, no popups, the screen
  stays awake.

## Next to Noctalia and Dux

Noctalia (now a native C++ shell with plugins and its own greeter) and Dux, formerly DankMaterialShell
(Quickshell and Go), are what people run on niri today, both with more widgets than Apolline.
Apolline doesn't race them on widgets:

- **Modes change the whole desktop and switch themselves.** Notifications, apps, performance, look and
  keys change together, and a mode can turn on while a game runs, on battery, at set hours or when a
  monitor is plugged in. Neither of them has rule-driven profiles.
- **Updates don't break it.** No Qt private API to break on a minor update; your niri config keeps one
  include line, and CI will run Apolline against every new niri release.
- **No surprise writes.** Coloring apps is opt-in, every file it writes is listed next to the switch,
  and turning it off removes exactly that. A gtk.css that is a dotfiles link is never touched.
- **Quiet at rest.** The shell wakes once a minute for the clock and repaints nothing else until something
  changes; if the GPU renderer can't start, it falls back to the CPU, so a driver problem can't keep you out.

## Principles

1. **Finished on first login.** Nothing to set up before it looks good. No modes until you make one.
2. **No guessing.** Every option has a control, a sentence that says what it does, and the exact
   lines it writes. Typos in the file are reported with the line and a suggestion; the rest applies.
3. **Your config stays yours.** Apolline adds one include line to niri and keeps a copy; it never edits
   your files again without a switch you turned on, and every such write can be undone.
4. **Keyboard first, mouse friendly.** Every overlay works with arrows, Enter and Esc, and closes
   on a click outside. Every shortcut is shown where the action is.
5. **Fast and quiet.** No polling where an event exists, nothing kept on disk that you didn't ask for.

## Done

- Bar: workspaces, pinned apps and open windows, clock, tray, notifications bell; top or bottom,
  floating or edge to edge, glass or frosted; one per monitor.
- Quick settings: Wi-Fi, Bluetooth, do not disturb, keep awake, power profile, volume and output device, microphone,
  brightness, player, notification history, screenshot, power, the battery's time left; a warning at
  10% and 5% on battery.
- Launcher: apps and Steam games, open windows, sums, actions, keyboard navigation.
- Lock screen (ext-session-lock + PAM, its own process), idle lock, lock before sleep, screen off.
- Polkit agent with its own dialog, on polkit's socket-activated helper.
- Notification daemon (actions and a click that opens the app, pictures, progress, per-app mute),
  OSD for volume, brightness, microphone and layout, clipboard history.
- Settings for everything below, with the file it writes and undo; a welcome window on first start.
- Modes you make yourself, with their own keys, that can switch themselves on.
- Windows: niri's Alt+Tab in Apolline colors, window settings, per-app rules.
- Rice: themes (gallery, save, share, `apolline theme next`), accent from the wallpaper, a wallpaper
  gallery from your folders, gradient borders, motion and open effects, blur, GTK and Qt apps in the accent.
- Arch package.

## Next

### 1. Modes — done
Out of the box there are no modes: one desktop, its wallpaper and accent. A mode is a named set of
changes you switch to with one key: wallpaper, accent, notifications, apps to open, performance,
keep awake and its own shortcuts. It can switch itself on while a game runs, on battery, at set hours
or when a monitor is plugged in; when that ends, the mode you had comes back, and switching by hand
always wins.

Settings → Modes shows what turned the current mode on, and a mode can wear a theme while it's on.

### 2. Many windows, comfortably — done
niri's Alt+Tab with live previews in Apolline colors, open windows and pinned apps on the bar, window
settings, opacity and animation speed, per-app rules, windows in the launcher.

### 3. Rice — mostly done
**Next:**
- **Layers you can see** — done for theme and tweaks: Settings names what you changed on top of the
  theme and takes you back to it in one click, and says what the running mode puts over it.
- **Themes as folders** — done: `theme.toml` with its wallpaper, `apolline theme install FILE|FOLDER`.
  Installs from a link too. A `niri.kdl` in the folder adds looks only (layout, animations, rules).
- **Per-surface style** — done for the bar (size, corners), the launcher (radius, opacity, size, list or
  grid), quick settings, notification cards and the volume popup; cards go in any corner.
- **Palettes** — done: light and dark, Catppuccin, Gruvbox, Nord, Tokyo Night, Rosé Pine, Everforest,
  Kanagawa, Dracula, Paper, or neutrals tinted from the wallpaper; any accent is shifted until it reads.
- **The bar's shape** — done: any of four edges, a strip or islands, its pieces dragged into place in
  Settings, pinned apps dragged on the bar itself, the apps' tray.
- **Lock screen and desktop** — done: the lock centered or in the corner, blurred; a clock on the wallpaper.
- **Templates** — done: any app's colors from a file of yours filled in from the palette.
- **Ten themes** — done, carrying the palette, the bar's shape and every surface's style.
- **Wallpapers**: done — a gallery from folders, one per monitor, rotation, a thumbnail cache and a cross-fade.
- **Fonts, icons, cursor and GTK theme** pickers — done.
- **More apps in the palette**: done for GTK, KDE and qt6ct apps, the whole palette and not only the
  accent, and running GTK apps change at once; Flatpak apps too.
- **A font per surface** and **the login screen in your look** — done.
- **A catalog of themes** in Settings, six to start with, each with its own wallpaper — done.
- **Russian** — done: the whole shell, dates included, app names from their own Russian lines, the login screen too.
- **Flatpak apps** in the palette — done, through a read-only user override Apolline takes back when coloring is off.
  Apolline ships no terminal templates; the Apolline terminal (its own project) reads the palette itself.

### 4. Finding things and getting in
- The launcher answers more — done: emoji by name, unit and currency conversion, files, and a dmenu
  mode (`apolline pick` reads lines from stdin) for your own scripts.
- Fingerprint next to the password on the lock screen, both at once — done, over fprintd's D-Bus API
  (tried against a fake reader, `tools/fake-bus.sh`). Off by default: a finger stands in for the
  password, so second factors in PAM don't apply to it. The polkit dialog can only ask through polkit's
  own helper, so there it is pam_fprintd in the polkit-1 PAM stack; the dialog talks to the helper from
  the moment it opens, so "place your finger" shows at once and a finger alone is enough.
- The login screen (`apolline greet`, done in its first form) remembers the last person and session and
  lists people through getent; `apolline greet --kiosk` starts cage with the system's keyboard layout.
  Next is no flash on the way into the session.
  It still needs a run on real hardware.

### 5. Displays and comfort
- VPN and WireGuard tunnels from NetworkManager in quick settings — done, tried against the fake.
- The apps' tray (StatusNotifierItem with DBusMenu menus) on the bar — done, tried against a fake app
  (`tools/fake-tray-app.py`); Steam, Discord and Telegram themselves are still to be seen.
- Settings → Displays: resolution, refresh rate, scale, arrangement, VRR, with a revert timer,
  validated with `niri validate` before it applies — done. Screens are arranged by dragging them on
  a map, where they settle against a neighbour's edge (tried on sample screens: nested niri has one).
- Night light on a schedule — done, still to be seen on real hardware (nested niri has no gamma control).
- Wi-Fi and Bluetooth over D-Bus instead of command-line tools — done: nearby networks with a password
  field (WPA2, WPA3, a typo asks again), pairing with a code, a PIN or a code to type, forgetting old
  ones, headphone battery. They follow NetworkManager's and BlueZ's signals instead of asking every few
  seconds. Tried against fakes (`tools/fake-bus.sh`); a run with real radios is still to come.
- A click on the clock: the month, today's weather from Open-Meteo, events from ICS files and
  https/webcal links, and CalDAV with the password in the Secret Service — done. Tried against
  Radicale and GNOME Keyring; Nextcloud and Fastmail are still to come.
- Capture: screenshots, a color picker, screen recording and marks on a screenshot (arrows, boxes, pen,
  marker, text, numbered steps, hidden parts) are done, and a mode can keep the last moments for one
  key to save (gpu-screen-recorder's replay); still to be seen on a real GPU.
- A bar module of your own — done (`[[module]]`: command, every, click).

### 6. Getting it to people
- Screenshots and a short video in the README, `apolline-git` on the AUR. CI builds, lints and tests
  on every push — done.
- CI against the newest niri — done for the config side: every week and on every push, the fragment for
  sample configs goes through `niri validate`. A session recorded on niri 26.04 replays in the tests,
  and CI records a fresh one from the newest niri (headless sway, `tools/niri-session.sh`) and reads it the same way.
- Idle CPU and memory measured on real hardware next to Noctalia and Dux, the same way each time:
  `tools/idle.sh 60 apolline qs dms` (CPU over a minute, memory as PSS).
  In a VM on Mesa's software renderer the shell idles at 0.2–0.4% CPU; its memory there is mostly llvmpipe's.
  At rest it starts no programs: the volume follows `pactl subscribe`, Wi-Fi and Bluetooth their D-Bus
  signals, and the rest of quick settings is read only while they are open.
- A Fedora COPR after the AUR.

## Not now

- **Plugins.** They freeze the API while it still changes every week. A bar module of your own covers
  most of what people write plugins for; when plugins come, each gets a CPU and memory budget.
- **A dock.** niri's strip plus windows and pinned apps on the bar already do its job.
- **An AI panel, a process monitor, a notepad.** Other apps do these well.
- **Later:** live wallpapers (video,
  shaders) in `apolline-wall`, a program and repository of its own that the shell will drive over JSON
  lines on stdin and stdout; pictures with crossfades already work there.
